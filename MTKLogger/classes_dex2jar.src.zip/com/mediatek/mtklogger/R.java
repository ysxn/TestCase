package com.mediatek.mtklogger;

public final class R
{
  public static final class array
  {
    public static final int entries_list_preference_aeemode = 2131099648;
    public static final int entries_list_preference_aeemode_oem = 2131099652;
    public static final int entries_list_preference_dal_setting = 2131099650;
    public static final int entryvalues_list_preference_aeemode = 2131099649;
    public static final int entryvalues_list_preference_aeemode_oem = 2131099653;
    public static final int entryvalues_list_preference_dal_setting = 2131099651;
    public static final int mode_list_preference = 2131099654;
    public static final int mode_value_list_preference = 2131099655;
  }
  
  public static final class attr {}
  
  public static final class drawable
  {
    public static final int bg_btn_selector = 2130837504;
    public static final int btn_history_overflow = 2130837505;
    public static final int ic_menu_contact_clear_select = 2130837506;
    public static final int ic_menu_contact_select_all = 2130837507;
    public static final int ic_menu_contact_trash = 2130837508;
    public static final int ic_menu_done_holo_dark = 2130837509;
    public static final int ic_notification_low_storage = 2130837510;
    public static final int ic_right_arrow = 2130837511;
    public static final int ic_settings = 2130837512;
    public static final int indicator_input_error = 2130837513;
    public static final int launcher = 2130837514;
    public static final int log_status_grey = 2130837515;
    public static final int log_status_red = 2130837516;
    public static final int notification = 2130837517;
    public static final int start = 2130837518;
    public static final int stop = 2130837519;
    public static final int taglog = 2130837520;
  }
  
  public static final class id
  {
    public static final int action_delete_selected = 2131296330;
    public static final int action_select_all = 2131296328;
    public static final int action_unselect_all = 2131296329;
    public static final int added_view = 2131296256;
    public static final int cancel_button = 2131296280;
    public static final int category_basic_info = 2131296314;
    public static final int category_detail_logs = 2131296317;
    public static final int category_logs = 2131296313;
    public static final int clearLogImageButton = 2131296306;
    public static final int clear_all_button = 2131296284;
    public static final int clear_all_cancel_linear_layout = 2131296283;
    public static final int clear_button = 2131296279;
    public static final int clear_cancel_linear_layout = 2131296278;
    public static final int clear_history = 2131296325;
    public static final int date_time = 2131296267;
    public static final int dialog_msg = 2131296257;
    public static final int done_menu_item = 2131296308;
    public static final int empty_view = 2131296272;
    public static final int error_icon = 2131296268;
    public static final int exception_detail_fragment = 2131296258;
    public static final int exit = 2131296327;
    public static final int feedback = 2131296262;
    public static final int freeStorageText = 2131296303;
    public static final int history_overflow_menu = 2131296324;
    public static final int history_report_layout = 2131296270;
    public static final int layout_reporter = 2131296260;
    public static final int level_process = 2131296266;
    public static final int limit_desc = 2131296310;
    public static final int list_view = 2131296271;
    public static final int logId = 2131296264;
    public static final int log_files_check_box = 2131296319;
    public static final int log_files_linear_layout = 2131296273;
    public static final int log_files_list_view = 2131296277;
    public static final int log_files_name = 2131296320;
    public static final int log_files_size = 2131296321;
    public static final int log_folder_linear_layout = 2131296281;
    public static final int log_folder_list_view = 2131296282;
    public static final int log_folder_name = 2131296322;
    public static final int log_selected = 2131296318;
    public static final int main_fragment = 2131296259;
    public static final int main_linear_layout = 2131296285;
    public static final int mobileLogImageView = 2131296292;
    public static final int mobileLogTextView = 2131296293;
    public static final int modemLogImageView = 2131296294;
    public static final int modemLogTextView = 2131296295;
    public static final int networkLogImageView = 2131296296;
    public static final int networkLogTextView = 2131296297;
    public static final int number_picker = 2131296311;
    public static final int pref_basic_info = 2131296312;
    public static final int pref_detail_info = 2131296315;
    public static final int relative1 = 2131296263;
    public static final int relative2 = 2131296265;
    public static final int report_status = 2131296316;
    public static final int right_arrow = 2131296323;
    public static final int savePathTextView = 2131296298;
    public static final int select_all_check_box = 2131296276;
    public static final int select_all_linear_layout = 2131296274;
    public static final int select_all_textview = 2131296275;
    public static final int select_items = 2131296309;
    public static final int set_history_limit = 2131296326;
    public static final int settingsImageButton = 2131296289;
    public static final int startStopToggleButton = 2131296307;
    public static final int storageChartLabel = 2131296302;
    public static final int storage_color_bar = 2131296300;
    public static final int submitter = 2131296261;
    public static final int tagImageButton = 2131296305;
    public static final int timeTextView = 2131296291;
    public static final int titleBarView = 2131296290;
    public static final int titleImageView = 2131296287;
    public static final int titleRelativeLayout = 2131296286;
    public static final int titleTextView = 2131296288;
    public static final int usedStorageText = 2131296301;
    public static final int view1 = 2131296299;
    public static final int view2 = 2131296304;
    public static final int whole_view = 2131296269;
  }
  
  public static final class layout
  {
    public static final int dialog_extend = 2130903040;
    public static final int exception_detail = 2130903041;
    public static final int exception_reporter = 2130903042;
    public static final int exception_reporter_fragment = 2130903043;
    public static final int history_adapter = 2130903044;
    public static final int history_main = 2130903045;
    public static final int log_files = 2130903046;
    public static final int log_folder = 2130903047;
    public static final int main = 2130903048;
    public static final int mobilelog_settings = 2130903049;
    public static final int modemlog_settings = 2130903050;
    public static final int multichoice_custom_action_bar = 2130903051;
    public static final int networklog_settings = 2130903052;
    public static final int picker_number_layout = 2130903053;
    public static final int pref_basic_info = 2130903054;
    public static final int pref_detail_info = 2130903055;
    public static final int pref_switch = 2130903056;
  }
  
  public static final class menu
  {
    public static final int history_action_bar = 2131230720;
    public static final int history_menu = 2131230721;
    public static final int mtklogger_contact_menu = 2131230722;
  }
  
  public static final class raw
  {
    public static final int alert = 2131034112;
  }
  
  public static final class string
  {
    public static final int advanced_settings_title = 2131165222;
    public static final int app_debugutils = 2131165309;
    public static final int app_history_name = 2131165411;
    public static final int app_name = 2131165184;
    public static final int basic_info = 2131165363;
    public static final int btn_giveup = 2131165354;
    public static final int btn_later = 2131165353;
    public static final int build_version = 2131165340;
    public static final int cancel = 2131165361;
    public static final int cancel_button = 2131165263;
    public static final int cancel_menu = 2131165259;
    public static final int chk_key_mobile_log = 2131165373;
    public static final int chk_key_modem_log = 2131165375;
    public static final int chk_key_net_log = 2131165374;
    public static final int clear_all_dlg_title = 2131165261;
    public static final int clear_all_menu = 2131165260;
    public static final int clear_btn = 2131165405;
    public static final int clear_confirm = 2131165398;
    public static final int clear_dialog_content = 2131165266;
    public static final int clear_dialog_title = 2131165265;
    public static final int clear_dlg_title = 2131165272;
    public static final int clear_history = 2131165397;
    public static final int clear_msg = 2131165402;
    public static final int clear_non_selected_item = 2131165271;
    public static final int cr_id = 2131165388;
    public static final int date_time = 2131165346;
    public static final int default_mode_value = 2131165302;
    public static final int delete = 2131165404;
    public static final int device_name = 2131165345;
    public static final int dialog_msg_manual_dump = 2131165364;
    public static final int dialog_send_cost_tip = 2131165351;
    public static final int dialog_send_tip = 2131165352;
    public static final int dialog_title_list_preference_aeemode = 2131165314;
    public static final int dialog_title_list_preference_dal_setting = 2131165318;
    public static final int dual_modem_log_name = 2131165198;
    public static final int dump_warning = 2131165304;
    public static final int empty_msg = 2131165396;
    public static final int enable_android_log_summary = 2131165238;
    public static final int enable_android_log_title = 2131165237;
    public static final int enable_bluetooth_log_summary = 2131165242;
    public static final int enable_bluetooth_log_title = 2131165241;
    public static final int enable_exception_reporter_summary = 2131165226;
    public static final int enable_exception_reporter_title = 2131165225;
    public static final int enable_kernel_log_summary = 2131165240;
    public static final int enable_kernel_log_title = 2131165239;
    public static final int enable_mobilelog = 2131165236;
    public static final int enable_modemlog = 2131165249;
    public static final int enable_networklog = 2131165254;
    public static final int enable_tag_log_summary = 2131165224;
    public static final int enable_tag_log_title = 2131165223;
    public static final int enable_ui_debug_mode_summary = 2131165228;
    public static final int enable_ui_debug_mode_title = 2131165227;
    public static final int error_cmd_timeout = 2131165282;
    public static final int error_common = 2131165285;
    public static final int error_create_log_folder_fail = 2131165283;
    public static final int error_deamon_die = 2131165278;
    public static final int error_deamon_unable = 2131165274;
    public static final int error_log_folder_deleted = 2131165281;
    public static final int error_send_cmd_fail = 2131165277;
    public static final int error_storage_full = 2131165276;
    public static final int error_storage_not_ready = 2131165275;
    public static final int error_storage_unavailable = 2131165280;
    public static final int error_tip = 2131165338;
    public static final int error_unsupport_log = 2131165279;
    public static final int error_wait_sd_timeout = 2131165284;
    public static final int exception_app_name = 2131165328;
    public static final int exception_class = 2131165341;
    public static final int exception_level = 2131165342;
    public static final int exception_type = 2131165344;
    public static final int exit = 2131165403;
    public static final int exp_db = 2131165360;
    public static final int feedback = 2131165333;
    public static final int feedback_hint = 2131165334;
    public static final int general_settings_title = 2131165221;
    public static final int history_limit = 2131165401;
    public static final int history_menu = 2131165412;
    public static final int histroy_label = 2131165395;
    public static final int info_wait_sd_ready = 2131165286;
    public static final int limit_log_size_dialog_message = 2131165245;
    public static final int limit_log_size_summary = 2131165244;
    public static final int limit_log_size_title = 2131165243;
    public static final int log2server_btn_cancel = 2131165332;
    public static final int log2server_btn_report = 2131165331;
    public static final int log2server_dialog_message = 2131165330;
    public static final int log2server_dialog_switch = 2131165348;
    public static final int log2server_dialog_title = 2131165329;
    public static final int log2server_send_progress_tip = 2131165349;
    public static final int log_free_storage = 2131165205;
    public static final int log_id = 2131165387;
    public static final int log_mode_summary = 2131165251;
    public static final int log_mode_title = 2131165250;
    public static final int log_path_not_exist = 2131165212;
    public static final int log_path_str = 2131165203;
    public static final int log_start = 2131165206;
    public static final int log_stop = 2131165207;
    public static final int log_storage_location_title = 2131165229;
    public static final int log_unselected = 2131165208;
    public static final int log_used_storage = 2131165204;
    public static final int logs = 2131165356;
    public static final int low_storage_warning_dialog_msg = 2131165214;
    public static final int low_storage_warning_dialog_title = 2131165213;
    public static final int memorydump_done = 2131165303;
    public static final int menu_clear = 2131165270;
    public static final int menu_select_all = 2131165268;
    public static final int menu_settings = 2131165200;
    public static final int menu_unselect_all = 2131165269;
    public static final int message_delete_all_log = 2131165262;
    public static final int message_deletelog = 2131165273;
    public static final int mobile_log = 2131165357;
    public static final int mobile_log_name = 2131165196;
    public static final int mobilelog_settings = 2131165235;
    public static final int mobilelog_unselected = 2131165201;
    public static final int modem_log = 2131165358;
    public static final int modem_log_name = 2131165197;
    public static final int modemlog_settings = 2131165248;
    public static final int msg_no_cr_id = 2131165389;
    public static final int msg_system_time_reset = 2131165327;
    public static final int net_log = 2131165359;
    public static final int network_gprs_tip = 2131165355;
    public static final int network_log_name = 2131165195;
    public static final int networklog_ping_summary = 2131165257;
    public static final int networklog_ping_title = 2131165256;
    public static final int networklog_settings = 2131165253;
    public static final int no = 2131165394;
    public static final int no_log_on = 2131165202;
    public static final int no_network_tip = 2131165350;
    public static final int notification_nearly_out_of_storage = 2131165193;
    public static final int notification_off_summary_suffix = 2131165191;
    public static final int notification_off_summary_suffixes = 2131165192;
    public static final int notification_on_summary_suffix = 2131165189;
    public static final int notification_on_summary_suffixes = 2131165190;
    public static final int notification_out_of_storage_summary = 2131165194;
    public static final int notification_title = 2131165188;
    public static final int notification_title_mobile = 2131165186;
    public static final int notification_title_modem = 2131165187;
    public static final int notification_title_network = 2131165185;
    public static final int ok = 2131165392;
    public static final int ok_button = 2131165264;
    public static final int phone_storage = 2131165210;
    public static final int pref_category_key_logs = 2131165407;
    public static final int pref_key_build_version = 2131165370;
    public static final int pref_key_cr_id = 2131165379;
    public static final int pref_key_date_time = 2131165372;
    public static final int pref_key_device_name = 2131165371;
    public static final int pref_key_exception_class = 2131165367;
    public static final int pref_key_exception_db = 2131165365;
    public static final int pref_key_exception_level = 2131165368;
    public static final int pref_key_exception_type = 2131165369;
    public static final int pref_key_log_id = 2131165378;
    public static final int pref_key_mobile_log = 2131165384;
    public static final int pref_key_modem_log = 2131165385;
    public static final int pref_key_network_log = 2131165386;
    public static final int pref_key_process_name = 2131165366;
    public static final int pref_key_upload_status = 2131165380;
    public static final int pref_key_upload_time = 2131165383;
    public static final int preference_aeemode = 2131165311;
    public static final int preference_cleandata = 2131165324;
    public static final int preference_cleardal = 2131165319;
    public static final int preference_dal_setting = 2131165315;
    public static final int preferences_aee_settings = 2131165310;
    public static final int preferences_device_maintain = 2131165323;
    public static final int process_name = 2131165339;
    public static final int reset_modem_msg = 2131165306;
    public static final int reset_modem_title = 2131165305;
    public static final int run_command_summary = 2131165231;
    public static final int run_command_title = 2131165230;
    public static final int run_exception_history = 2131165232;
    public static final int run_exception_history_summary = 2131165233;
    public static final int sd_card = 2131165211;
    public static final int selected_item_count = 2131165267;
    public static final int send = 2131165362;
    public static final int send_filter_fail_msg = 2131165308;
    public static final int send_filter_fail_title = 2131165307;
    public static final int set = 2131165406;
    public static final int set_history_limit = 2131165400;
    public static final int set_limit_desc = 2131165399;
    public static final int size = 2131165376;
    public static final int start_automatically_mobile_summary = 2131165247;
    public static final int start_automatically_modem_summary = 2131165252;
    public static final int start_automatically_network_summary = 2131165255;
    public static final int start_automatically_title = 2131165246;
    public static final int status = 2131165377;
    public static final int status_not_uploaded = 2131165382;
    public static final int status_uploaded = 2131165381;
    public static final int submitter = 2131165335;
    public static final int submitter_hint = 2131165337;
    public static final int submitter_tip = 2131165336;
    public static final int success_message_with_crid = 2131165410;
    public static final int success_message_with_logid = 2131165409;
    public static final int success_tip = 2131165347;
    public static final int summary_preference_aeemode = 2131165313;
    public static final int summary_preference_cleandata = 2131165325;
    public static final int summary_preference_cleardal = 2131165320;
    public static final int summary_preference_dal_setting = 2131165317;
    public static final int tag_log_name = 2131165199;
    public static final int taglog = 2131165287;
    public static final int taglog_busy = 2131165299;
    public static final int taglog_compress_done = 2131165300;
    public static final int taglog_exit = 2131165301;
    public static final int taglog_msg_compress_log = 2131165297;
    public static final int taglog_msg_input = 2131165292;
    public static final int taglog_msg_logtool_stopped = 2131165293;
    public static final int taglog_msg_no_sdcard = 2131165295;
    public static final int taglog_msg_no_space = 2131165291;
    public static final int taglog_msg_sdcard_not_writtable = 2131165296;
    public static final int taglog_msg_zip_log_fail = 2131165294;
    public static final int taglog_run_in_background_button = 2131165298;
    public static final int taglog_title = 2131165288;
    public static final int taglog_title_no_space = 2131165290;
    public static final int taglog_title_warning = 2131165289;
    public static final int time_default = 2131165209;
    public static final int title_activity_log_folder_list = 2131165258;
    public static final int title_preference_aeemode = 2131165312;
    public static final int title_preference_cleandata = 2131165326;
    public static final int title_preference_cleardal = 2131165321;
    public static final int title_preference_dal_setting = 2131165316;
    public static final int title_preferences_device_maintain = 2131165322;
    public static final int upload_status = 2131165390;
    public static final int upload_time = 2131165391;
    public static final int view_history = 2131165408;
    public static final int waiting_dialog_message_poll_log = 2131165220;
    public static final int waiting_dialog_message_start_log = 2131165216;
    public static final int waiting_dialog_message_stop_log = 2131165218;
    public static final int waiting_dialog_title_poll_log = 2131165219;
    public static final int waiting_dialog_title_start_log = 2131165215;
    public static final int waiting_dialog_title_stop_log = 2131165217;
    public static final int warning_no_permission_for_setting = 2131165234;
    public static final int wifi_username = 2131165343;
    public static final int yes = 2131165393;
  }
  
  public static final class xml
  {
    public static final int log_files_item = 2130968576;
    public static final int log_folder_item = 2130968577;
    public static final int preference_debugtoolbox = 2130968578;
    public static final int settings = 2130968579;
  }
}


/* Location:           D:\apktool\MTKLogger\classes_dex2jar.jar
 * Qualified Name:     com.mediatek.mtklogger.R
 * JD-Core Version:    0.7.0.1
 */