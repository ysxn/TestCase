package me.undownding.phonedetect;

import java.util.Locale;

public class Main implements  PhoneUtil.Callback {

    public static void main (String[] args) {
        PhoneUtil.detect("4008823823", new Main());
    }

    @Override
    public void onResult(String phoneNumber, String result, int responseCode, Exception e) {
        System.out.println(String.format(Locale.getDefault(),
                "onResult phoneNumber = %s, result = %s, responseCode = %s, e = %s",
                phoneNumber, result, responseCode, e));
    }
}
