package me.undownding.phonedetect;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Locale;

public class PhoneUtil {

    // RESTful API of Sogou
    private static final String REST_URL =
            "http://data.haoma.sogou.com/vrapi/query_number.php?" +
                    "number=%s&type=json&callback=show";

    public synchronized static void detect(final String phoneNumber, final Callback callback) {
        final String restURL = String.format(Locale.getDefault(), REST_URL, phoneNumber);
        new Thread() {
            @Override
            public void run() {

                InputStream inputStream;
                InputStreamReader inputStreamReader;
                BufferedReader reader;
                StringBuilder resultBuilder = new StringBuilder();
                String tempLine;

                try {
                    URL localURL = new URL(restURL);
                    URLConnection connection = localURL.openConnection();
                    HttpURLConnection httpURLConnection = (HttpURLConnection) connection;

                    httpURLConnection.setRequestProperty("Accept-Charset", "utf-8");
                    httpURLConnection.setRequestProperty("Content-Type", "application/json");

                    inputStream = httpURLConnection.getInputStream();
                    inputStreamReader = new InputStreamReader(inputStream);
                    reader = new BufferedReader(inputStreamReader);

                    while ((tempLine = reader.readLine()) != null) {
                        resultBuilder.append(tempLine);
                    }

                    reader.close();
                    inputStreamReader.close();
                    inputStream.close();

                    callback.onResult(phoneNumber,
                            getInfomationfromResult(resultBuilder.toString()),
                            httpURLConnection.getResponseCode(),
                            null);
                } catch (Exception e) {
                    e.printStackTrace();
                    callback.onResult(phoneNumber, "", -1, e);
                }
            }
        }.start();
    }

    private static String getInfomationfromResult(String result) {
        try {
            String info = result.substring(5, result.length() - 1);
            JSONObject json = new JSONObject(info);
            info = json.getString("NumInfo");
            String splitResult[] = info.split("：");
            return splitResult[splitResult.length > 1 ? 1 : 0];
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return "";
    }
    public interface Callback {
        // e == null means success
        void onResult(String phoneNumber, String result, int responseCode, Exception e);
    }
}
